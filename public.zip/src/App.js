import React from "react";
import './App.css';

import Table from './Table';

function App() {
  return (
    <div >
     <Table />
    </div>
  );
}

export default App;
